<?php
/**
 * Tijarah Child Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Tijarah Child
 * @since 1.0.0
 */

add_action( 'wp_enqueue_scripts', 'tijarah_enqueue_styles' );
function tijarah_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css',array('tijarah-plugin') ); 
}

/**
 * USE DUPLICATE SKU
 */


add_filter( 'wc_product_has_unique_sku', '__return_false', PHP_INT_MAX );

/**
 * CHANGE SKU TEXT
 */
function translate_woocommerce($translation, $text, $domain) {
    if ($domain == 'woocommerce') {
        switch ($text) {
            case 'SKU':
                $translation = 'VERSION';
                break;
            case 'SKU:':
                $translation = 'VERSION:';
                break;
        }
    }
    return $translation;
}

add_filter('gettext', 'translate_woocommerce', 10, 3);


/**